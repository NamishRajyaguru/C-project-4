#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define MAX 100

void application(char *content, const char *specialword, const char *newword) {
    char *ptr = strstr(content, specialword);
    if (ptr != NULL) {
        char temp[MAX * 10];
        strcpy(temp, ptr + strlen(specialword));
        *ptr = '\0';
        strcat(content, newword);
        strcat(content, temp);
    }
}

int main() {
    char NAME[MAX], ENROLL[MAX], DEPARTMENT[MAX], TYPEOFDOC[MAX], content[MAX * 10];
    FILE *file;
    long file_size;

    printf("What type of application do you want : TYPE either one of these (LEAVE, APOLOGY) ");
    scanf("%s", TYPEOFDOC);
    getchar();

    printf("Enter your full name : ");
    fgets(NAME, MAX, stdin);
    NAME[strcspn(NAME, "\n")] = '\0';

    printf("Enter your Enrollment number : ");
    fgets(ENROLL, MAX, stdin);
    ENROLL[strcspn(ENROLL, "\n")] = '\0';

    printf("Enter your department : ");
    fgets(DEPARTMENT, MAX, stdin);
    DEPARTMENT[strcspn(DEPARTMENT, "\n")] = '\0';

    if (strcmp(TYPEOFDOC, "LEAVE") == 0) {
        file = fopen("leave.txt", "r");
    } else if (strcmp(TYPEOFDOC, "APOLOGY") == 0) {
        file = fopen("apology.txt", "r");
    } else {
        printf("INVALID INPUT !!\n");
        return 1;
    }

    if (file == NULL) {
        printf("Error opening file!!\n");
        return 1;
    }

    fseek(file, 0, SEEK_END);
    file_size = ftell(file);
    rewind(file);

    if (file_size >= sizeof(content)) {
        printf("File too large!!\n");
        fclose(file);
        return 1;
    }

    fread(content, 1, file_size, file);
    content[file_size] = '\0';
    fclose(file);

    application(content, "{{name}}", NAME);
    application(content, "{{enroll}}", ENROLL);
    application(content, "{{dep}}", DEPARTMENT);

    printf("\n%s\n", content);

    return 0;
}
